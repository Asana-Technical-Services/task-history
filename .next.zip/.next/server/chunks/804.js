"use strict";
exports.id = 804;
exports.ids = [804];
exports.modules = {

/***/ 804:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_withAuth)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(282);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(731);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(297);
// EXTERNAL MODULE: external "next-auth/client"
var client_ = __webpack_require__(104);
;// CONCATENATED MODULE: ./src/components/Login.tsx



function Login() {
  var _session$user;

  const [session, loading] = (0,client_.useSession)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [!session && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      children: ["Not signed in ", /*#__PURE__*/jsx_runtime_.jsx("br", {}), /*#__PURE__*/jsx_runtime_.jsx("button", {
        onClick: () => (0,client_.signIn)(),
        children: "Connect to Asana"
      })]
    }), session && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      children: ["Signed in as ", (_session$user = session.user) === null || _session$user === void 0 ? void 0 : _session$user.name, " ", /*#__PURE__*/jsx_runtime_.jsx("br", {}), /*#__PURE__*/jsx_runtime_.jsx("button", {
        onClick: () => (0,client_.signOut)(),
        children: "Sign out"
      })]
    })]
  });
}
;// CONCATENATED MODULE: ./src/components/withAuth.tsx



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const withAuth = WrappedComponent => props => {
  const [session, sessionLoading] = (0,client_.useSession)();
  const Router = (0,router_.useRouter)();
  (0,external_react_.useEffect)(() => {
    if (typeof (session === null || session === void 0 ? void 0 : session.accessToken) !== "string") {
      Router.replace("/signin");
      return;
    }
  }, [session]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx(Login, {}), /*#__PURE__*/jsx_runtime_.jsx(WrappedComponent, _objectSpread({}, props))]
  });
};

/* harmony default export */ const components_withAuth = (withAuth);

/***/ })

};
;