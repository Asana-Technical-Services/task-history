"use strict";
(() => {
var exports = {};
exports.id = 748;
exports.ids = [748];
exports.modules = {

/***/ 555:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _nextauth_)
});

;// CONCATENATED MODULE: external "next-auth"
const external_next_auth_namespaceObject = require("next-auth");
var external_next_auth_default = /*#__PURE__*/__webpack_require__.n(external_next_auth_namespaceObject);
;// CONCATENATED MODULE: external "next-auth/providers"
const providers_namespaceObject = require("next-auth/providers");
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(376);
;// CONCATENATED MODULE: ./pages/api/auth/[...nextauth].js



/* harmony default export */ const _nextauth_ = (external_next_auth_default()({
  // Configure one or more authentication providers
  providers: [{
    id: "asana",
    name: "Asana",
    type: "oauth",
    version: "2.0",
    scope: [],
    params: {
      grant_type: "authorization_code"
    },
    accessTokenUrl: "https://app.asana.com/-/oauth_token",
    requestTokenUrl: "https://app.asana.com/-/oauth_authorize",
    authorizationUrl: "https://app.asana.com/-/oauth_authorize?response_type=code",
    profileUrl: "https://app.asana.com/api/1.0/users/me",

    async profile(profile, tokens) {
      var _profile$data, _profile$data2, _profile$data3, _profile$data3$photo;

      // You can use the tokens, in case you want to fetch more profile information
      // For example several OAuth providers do not return email by default.
      // Depending on your provider, will have tokens like `access_token`, `id_token` and or `refresh_token`
      console.log(profile, tokens);
      return {
        id: profile.data.gid,
        name: (_profile$data = profile.data) === null || _profile$data === void 0 ? void 0 : _profile$data.name,
        email: (_profile$data2 = profile.data) === null || _profile$data2 === void 0 ? void 0 : _profile$data2.email,
        image: (_profile$data3 = profile.data) === null || _profile$data3 === void 0 ? void 0 : (_profile$data3$photo = _profile$data3.photo) === null || _profile$data3$photo === void 0 ? void 0 : _profile$data3$photo.image_128x128
      };
    },

    clientId: process.env.NEXT_CLIENT_ID,
    clientSecret: process.env.NEXT_CLIENT_SECRET
  }],
  pages: {
    signIn: "/signin"
  },
  callbacks: {
    /**
     * @param  {object}  token     Decrypted JSON Web Token
     * @param  {object}  user      User object      (only available on sign in)
     * @param  {object}  account   Provider account (only available on sign in)
     * @param  {object}  profile   Provider profile (only available on sign in)
     * @param  {boolean} isNewUser True if new user (only available on sign in)
     * @return {object}            JSON Web Token that will be saved
     */
    async jwt(token, user, account, profile, isNewUser) {
      console.log(account, token); // Add access_token to the token right after signin

      if (account !== null && account !== void 0 && account.accessToken) {
        token.accessToken = account.accessToken;
      }

      return token;
    },

    /**
     * @param  {object} session      Session object
     * @param  {object} token        User object    (if using database sessions)
     *                               JSON Web Token (if not using database sessions)
     * @return {object}              Session that will be returned to the client
     */
    async session(session, token) {
      console.log(session, token); // Add access_token to session

      session.accessToken = token.accessToken;
      return session;
    }

  },
  useSecureCookies: true
})); // session: { jwt: true },
//   jwt: {
//     // A secret to use for key generation - you should set this explicitly
//     // Defaults to NextAuth.js secret if not explicitly specified.
//     // This is used to generate the actual signingKey and produces a warning
//     // message if not defined explicitly.
//     secret: "INp8IvdIyeMcoGAgFGoA61DdBglwwSqnXJZkgz8PSnw",
//     // You can generate a signing key using `jose newkey -s 512 -t oct -a HS512`
//     // This gives you direct knowledge of the key used to sign the token so you can use it
//     // to authenticate indirectly (eg. to a database driver)
//     signingKey: {
//       kty: "oct",
//       kid: "Dl893BEV-iVE-x9EC52TDmlJUgGm9oZ99_ZL025Hc5Q",
//       alg: "HS512",
//       k: "K7QqRmJOKRK2qcCKV_pi9PSBv3XP0fpTu30TP8xn4w01xR3ZMZM38yL2DnTVPVw6e4yhdh0jtoah-i4c_pZagA",
//     },
//     // If you chose something other than the default algorithm for the signingKey (HS512)
//     // you also need to configure the algorithm
//     verificationOptions: {
//       algorithms: ["HS256"],
//     },
//     secureCookie: true,
//     // Set to true to use encryption. Defaults to false (signing only).
//     encryption: true,
//     encryptionKey: process.env.NEXT_ENCRYPTION_KEY,
//     // decryptionKey: encryptionKey,
//     decryptionOptions: {
//       algorithms: ["A256GCM"],
//     },
//   },

/***/ }),

/***/ 376:
/***/ ((module) => {

module.exports = require("axios");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(555));
module.exports = __webpack_exports__;

})();